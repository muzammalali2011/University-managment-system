<?php
session_start();

// Base URL configuration
define('BASE_PATH', '/DB_project');
define('STUDENT_PATH', BASE_PATH . '/students');
define('ADMIN_PATH', BASE_PATH . '/admin');
define('PROFESSOR_PATH', BASE_PATH . '/professors');

// Database connection
require_once __DIR__ . '/../config/db.php';

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

/**
 * Check if user has specific role
 */
function hasRole($role) {
    return isLoggedIn() && $_SESSION['role'] === $role;
}

/**
 * Require login, redirect if not logged in
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: " . BASE_PATH . "/login.php");
        exit();
    }
}

/**
 * Require specific role, redirect if not authorized
 */
function requireRole($role) {
    requireLogin();
    if (!hasRole($role)) {
        header("Location: " . BASE_PATH . "/403.php");
        exit();
    }
}

/**
 * NEW: Check role without requiring login first
 * (For cases where login is already verified)
 */
function checkRole($role) {
    if (!hasRole($role)) {
        header("Location: " . BASE_PATH . "/403.php");
        exit();
    }
}

/**
 * NEW: Require admin privileges with context check
 */
function requireAdmin() {
    requireRole('admin');
    ensureAdminContext();
}

/**
 * Ensure admin is in admin context
 */
function ensureAdminContext() {
    if (strpos($_SERVER['REQUEST_URI'], '/admin/') === false) {
        header("Location: " . ADMIN_PATH . "/index.php");
        exit();
    }
}

/**
 * Ensure student is in student context
 */
function ensureStudentContext() {
    if (strpos($_SERVER['REQUEST_URI'], '/students/') === false) {
        header("Location: " . STUDENT_PATH . "/index.php");
        exit();
    }
}

/**
 * Ensure professor is in professor context
 */
function ensureProfessorContext() {
    if (strpos($_SERVER['REQUEST_URI'], '/professors/') === false) {
        header("Location: " . PROFESSOR_PATH . "/index.php");
        exit();
    }
}

/**
 * Get database connection
 */
function getDB() {
    return $GLOBALS['pdo'];
}

/**
 * Get current user's ID
 */
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user's role
 */
function getUserRole() {
    return $_SESSION['role'] ?? null;
}

/**
 * Get current user's associated ID
 */
function getAssociatedId() {
    return $_SESSION['associated_id'] ?? null;
}