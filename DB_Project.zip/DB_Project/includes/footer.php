<?php
// filepath: e:\xaamp\htdocs\DB_Project\includes\footer.php
?>
<footer>
    <div style="text-align: center; padding: 10px; background-color: #f4f4f4; margin-top: 20px;">
        <p>&copy; <?php echo date('Y'); ?> DB Project. All rights reserved.</p>
    </div>
</footer>
</body>
</html>