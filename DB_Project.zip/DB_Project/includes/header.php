<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'University System' ?></title>
    <link rel="stylesheet" href="/DB_project/assets/css/style.css">
    <style>
        /* Header Styles */
        .main-header {
            background-color: #2c3e50;
            color: white;
            padding: 0.8rem 2rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .main-header h1 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .main-header h1 a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .main-header h1 a::before {
            content: "🏛️"; /* University emoji */
            font-size: 1.3rem;
        }
        
        .main-nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            gap: 1.5rem;
            align-items: center;
        }
        
        .main-nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0;
            position: relative;
            transition: all 0.3s ease;
        }
        
        .main-nav a:hover {
            opacity: 0.9;
        }
        
        .main-nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background-color: #3498db;
            transition: width 0.3s ease;
        }
        
        .main-nav a:hover::after {
            width: 100%;
        }
        
        .main-nav span {
            color: #ecf0f1;
            font-size: 0.95rem;
        }
        
        .content-wrapper {
            min-height: calc(100vh - 120px);
            padding: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                padding: 1rem 0;
            }
            
            .main-nav ul {
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <header class="main-header">
        <div class="header-content">
            <h1><a href="/DB_project/index.php">University Managment System</a></h1>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="/DB_project/index.php">Home</a></li>
                    
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li><span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span></li>
                        <li><a href="/DB_project/logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="/DB_project/login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="content-wrapper">