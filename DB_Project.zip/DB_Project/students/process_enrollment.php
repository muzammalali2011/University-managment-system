<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
ensureStudentContext();

$pdo = getDB();
$student_id = $_SESSION['associated_id'];

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Validate input
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['class_id'])) {
    $_SESSION['error'] = "Invalid request";
    header("Location: enroll.php");
    exit();
}

$class_id = (int)$_POST['class_id'];
$course_id = (int)$_POST['course_id'];

try {
    // Get class details
    $classQuery = $pdo->prepare("
        SELECT cl.*, c.course_name, p.prof_id 
        FROM classes cl
        JOIN courses c ON cl.course_id = c.course_id
        JOIN professors p ON cl.prof_id = p.prof_id
        WHERE cl.class_id = ?
    ");
    $classQuery->execute([$class_id]);
    $class = $classQuery->fetch();

    if (!$class) {
        throw new Exception("Invalid class selected");
    }

    // Check if already enrolled
    $enrollmentCheck = $pdo->prepare("
        SELECT 1 FROM enrollments 
        WHERE student_id = ? AND class_id = ?
    ");
    $enrollmentCheck->execute([$student_id, $class_id]);
    
    if ($enrollmentCheck->fetch()) {
        throw new Exception("You are already enrolled in this class");
    }

    // Create enrollment request
    $insertRequest = $pdo->prepare("
        INSERT INTO enrollment_requests 
        (student_id, course_id, class_id,professor_id, status)
        VALUES (?, ?, ?,?,'pending')
    ");
    $insertRequest->execute([
        $student_id,
        $course_id,
        $class_id, 
        $class['prof_id']
    ]);

    $_SESSION['success'] = "Enrollment request submitted for " . htmlspecialchars($class['course_name']);
    header("Location: index.php");
    exit();

} catch (Exception $e) {
    error_log("Enrollment error: " . $e->getMessage());
    $_SESSION['error'] = $e->getMessage();
    header("Location: enroll.php");
    exit();
}