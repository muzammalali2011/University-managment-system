<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');

$pdo = getDB();
$student_id = $_SESSION['associated_id'];

// Query to get grades
$query = $pdo->prepare("
    SELECT c.course_name, e.letter_grade AS grade, cl.semester, cl.year
    FROM enrollments e
    JOIN classes cl ON e.class_id = cl.class_id
    JOIN courses c ON cl.course_id = c.course_id
    WHERE e.student_id = ? AND e.letter_grade IS NOT NULL
    ORDER BY cl.year DESC, cl.semester DESC
");
$query->execute([$student_id]);
$grades = $query->fetchAll();

$pageTitle = "My Grades";
include __DIR__ . '/../includes/header.php';
?>

<main class="student-container">
    <div class="student-header">
        <h1><i class="icon-grades"></i> My Academic Progress</h1>
        <div class="header-actions">
            <a href="index.php" class="btn-back"><i class="icon-back"></i> Back to Dashboard</a>
        </div>
    </div>

    <div class="student-card">
        <?php if (count($grades) > 0): ?>
            <div class="table-responsive">
                <table class="student-table">
                    <thead>
                        <tr>
                            <th>Course</th>
                            <th>Grade</th>
                            <th>Semester</th>
                            <th>Year</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grades as $grade): ?>
                            <tr>
                                <td><?= htmlspecialchars($grade['course_name']) ?></td>
                                <td class="grade-value"><?= htmlspecialchars($grade['grade']) ?></td>
                                <td>
                                    <span class="semester-badge semester-<?= strtolower($grade['semester']) ?>">
                                        <?= htmlspecialchars($grade['semester']) ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($grade['year']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="icon-warning"></i>
                <p>No grades available yet.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<style>
    /* Reuse student container styles */
    .student-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
    }
    
    .student-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #eee;
    }
    
    .student-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .btn-back {
        color: #4361ee;
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        transition: all 0.3s ease;
    }
    
    .btn-back:hover {
        background-color: #f0f4ff;
    }
    
    /* Card Styles */
    .student-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 15px rgba(0,0,0,0.08);
        padding: 1.5rem;
    }
    
    /* Table Styles */
    .table-responsive {
        overflow-x: auto;
    }
    
    .student-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .student-table th {
        background-color: #f8f9fa;
        color: #3a4a6b;
        padding: 0.8rem 1rem;
        text-align: left;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .student-table td {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        vertical-align: middle;
    }
    
    .student-table tr:last-child td {
        border-bottom: none;
    }
    
    /* Grade Value */
    .grade-value {
        font-weight: 600;
        color: #388e3c;
    }
    
    /* Semester Badges */
    .semester-badge {
        display: inline-block;
        padding: 0.3rem 0.6rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
    }
    
    .semester-fall {
        background-color: #fff3e0;
        color: #e65100;
    }
    
    .semester-spring {
        background-color: #e8f5e9;
        color: #2e7d32;
    }
    
    .semester-summer {
        background-color: #e3f2fd;
        color: #1565c0;
    }
    
    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 3rem;
        color: #7f8c8d;
    }
    
    .empty-state i {
        font-size: 2.5rem;
        opacity: 0.5;
        margin-bottom: 1rem;
        display: block;
    }
    
    /* Icons */
    .icon-grades::before { content: "📊"; }
    .icon-back::before { content: "←"; }
    .icon-warning::before { content: "⚠️"; }
    
    @media (max-width: 768px) {
        .student-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .header-actions {
            width: 100%;
            justify-content: flex-end;
        }
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>