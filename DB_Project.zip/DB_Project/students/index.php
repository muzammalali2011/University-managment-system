<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
requireRole('student');
ensureStudentContext();

// Get student's name
$studentName = $_SESSION['first_name'] ?? 'Student';
$username = $_SESSION['username'] ?? '';

$pageTitle = "Student Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<main class="student-container">
    <div class="student-header">
        <h1><i class="icon-welcome"></i> Welcome, <?= htmlspecialchars($studentName) ?> <small>(<?= htmlspecialchars($username) ?>)</small></h1>
        <div class="header-actions">
            <a href="../logout.php" class="btn-logout"><i class="icon-logout"></i> Logout</a>
        </div>
    </div>
    
    <div class="dashboard-grid">
        <div class="dashboard-card">
            <div class="card-icon courses-icon">
                <i class="icon-courses"></i>
            </div>
            <div class="card-content">
                <h3>My Courses</h3>
                <p>View your current course enrollments</p>
                <a href="courses.php" class="btn btn-primary">
                    <i class="icon-view"></i> View Courses
                </a>
            </div>
        </div>
        
        <div class="dashboard-card">
            <div class="card-icon enroll-icon">
                <i class="icon-enroll"></i>
            </div>
            <div class="card-content">
                <h3>Enroll in Courses</h3>
                <p>Register for new courses</p>
                <a href="enroll.php" class="btn btn-success">
                    <i class="icon-add"></i> Enroll Now
                </a>
            </div>
        </div>
        
        <div class="dashboard-card">
            <div class="card-icon grades-icon">
                <i class="icon-grades"></i>
            </div>
            <div class="card-content">
                <h3>View Grades</h3>
                <p>Check your academic progress</p>
                <a href="grades.php" class="btn btn-info">
                    <i class="icon-check"></i> View Grades
                </a>
            </div>
        </div>
    </div>
</main>

<style>
    /* Main Container */
    .student-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
    }
    
    /* Header Styles */
    .student-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #eee;
    }
    
    .student-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .student-header h1 small {
        font-size: 1rem;
        color: #7f8c8d;
        font-weight: normal;
    }
    
    .header-actions {
        display: flex;
        gap: 1rem;
    }
    
    .btn-logout {
        color: #e74c3c;
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        transition: all 0.3s ease;
    }
    
    .btn-logout:hover {
        background-color: #ffebee;
    }
    
    /* Dashboard Grid */
    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
    }
    
    /* Cards */
    .dashboard-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        display: flex;
        flex-direction: column;
    }
    
    .dashboard-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    
    .card-icon {
        padding: 1.5rem;
        display: flex;
        justify-content: center;
        font-size: 2.5rem;
    }
    
    .courses-icon { background-color: #e3f2fd; color: #1976d2; }
    .enroll-icon { background-color: #fff8e1; color: #ff8f00; }
    .grades-icon { background-color: #e8f5e9; color: #388e3c; }
    
    .card-content {
        padding: 1.5rem;
        flex-grow: 1;
    }
    
    .card-content h3 {
        margin-top: 0;
        color: #2c3e50;
        font-size: 1.3rem;
    }
    
    .card-content p {
        color: #7f8c8d;
        margin-bottom: 1.5rem;
    }
    
    /* Buttons */
    .btn {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.7rem 1.2rem;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 500;
        transition: all 0.3s ease;
        border: none;
        cursor: pointer;
    }
    
    .btn-primary {
        background-color: #1976d2;
        color: white;
    }
    
    .btn-success {
        background-color: #388e3c;
        color: white;
    }
    
    .btn-info {
        background-color: #00acc1;
        color: white;
    }
    
    .btn:hover {
        opacity: 0.9;
        transform: translateY(-2px);
    }
    
    /* Icons */
    .icon-welcome::before { content: "👋"; }
    .icon-logout::before { content: "🚪"; }
    .icon-courses::before { content: "📚"; }
    .icon-enroll::before { content: "📝"; }
    .icon-grades::before { content: "🏆"; }
    .icon-view::before { content: "👀"; }
    .icon-add::before { content: "➕"; }
    .icon-check::before { content: "✅"; }
    
    @media (max-width: 768px) {
        .student-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .header-actions {
            width: 100%;
            justify-content: flex-end;
        }
        
        .dashboard-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>