<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('student');
ensureStudentContext();

$pdo = getDB();
$student_id = $_SESSION['associated_id'];
error_reporting(E_ALL);
ini_set('display_errors', 1);
// If no specific course requested, show available courses
if (!isset($_GET['course_id'])) {
    $pageTitle = "Available Courses";
    include __DIR__ . '/../includes/header.php';
    
    try {
        $availableCourses = $pdo->prepare("
            SELECT c.course_id, c.course_name, c.credits, d.dept_name,
                   (SELECT COUNT(*) FROM classes WHERE course_id = c.course_id) as section_count
            FROM courses c
            JOIN departments d ON c.dept_id = d.dept_id
            WHERE c.is_approved = 1
            AND c.course_id NOT IN (
                SELECT cl.course_id 
                FROM enrollments e
                JOIN classes cl ON e.class_id = cl.class_id
                WHERE e.student_id = ?
            )
            AND c.course_id NOT IN (
                SELECT course_id 
                FROM enrollment_requests 
                WHERE student_id = ? AND status = 'pending'
            )
            HAVING section_count > 0
            ORDER BY c.course_name
        ");
        $availableCourses->execute([$student_id, $student_id]);
        $courses = $availableCourses->fetchAll();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// Test with student_id=1
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        $_SESSION['error'] = "Error loading available courses";
        header("Location: index.php");
        exit();
    }
    ?>
    
    <main class="container">
        <div class="header">
            <h1><i class="fas fa-book-open"></i> Available Courses</h1>
            <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <?php if (!empty($courses)): ?>
            <div class="table-container">
                <table class="course-table">
                    <thead>
                        <tr>
                            <th>Course Name</th>
                            <th>Credits</th>
                            <th>Department</th>
                            <th>Sections Available</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($courses as $course): ?>
                        <tr>
                            <td><?= htmlspecialchars($course['course_name']) ?></td>
                            <td><?= htmlspecialchars($course['credits']) ?></td>
                            <td><?= htmlspecialchars($course['dept_name']) ?></td>
                            <td><?= htmlspecialchars($course['section_count']) ?></td>
                            <td>
                                <a href="enroll.php?course_id=<?= $course['course_id'] ?>" class="enroll-btn">
                                    <i class="fas fa-user-plus"></i> Enroll Now
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-message">
                <i class="fas fa-info-circle"></i>
                <p>No available courses found.</p>
            </div>
        <?php endif; ?>
    </main>

    <style>
        /* Main Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .header h1 {
            color: #2c3e50;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Back Button */
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 8px 15px;
            background-color: #f8f9fa;
            color: #495057;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .back-btn:hover {
            background-color: #e9ecef;
        }
        
        /* Alert */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        
        /* Table */
        .table-container {
            overflow-x: auto;
        }
        
        .course-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .course-table th {
            background-color: #f8f9fa;
            color: #495057;
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        
        .course-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
            vertical-align: middle;
        }
        
        .course-table tr:last-child td {
            border-bottom: none;
        }
        
        /* Enroll Button */
        .enroll-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 8px 15px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .enroll-btn:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }
        
        /* Empty Message */
        .empty-message {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        
        .empty-message i {
            font-size: 40px;
            margin-bottom: 15px;
            color: #6c757d;
        }
        
        /* Font Awesome Icons */
        .fas {
            font-size: 16px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .course-table {
                font-size: 14px;
            }
            
            .enroll-btn {
                padding: 6px 10px;
                font-size: 14px;
            }
        }
    </style>

    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <?php include __DIR__ . '/../includes/footer.php';
    exit();
}

// If course_id is provided, show enrollment form for that course
$course_id = (int)$_GET['course_id'];

// Check if course exists and is approved
try {
    $courseQuery = $pdo->prepare("
        SELECT c.course_id, c.course_name, d.dept_name 
        FROM courses c
        JOIN departments d ON c.dept_id = d.dept_id
        WHERE c.course_id = ? AND c.is_approved = 1
    ");
    $courseQuery->execute([$course_id]);
    $course = $courseQuery->fetch();

    if (!$course) {
        $_SESSION['error'] = "Invalid course selection";
        header("Location: index.php");
        exit();
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $_SESSION['error'] = "Error verifying course";
    header("Location: index.php");
    exit();
}

// Check if already enrolled or pending
try {
    $enrollmentQuery = $pdo->prepare("
        SELECT 1 FROM enrollments e
        JOIN classes cl ON e.class_id = cl.class_id
        WHERE e.student_id = ? AND cl.course_id = ?
        UNION
        SELECT 1 FROM enrollment_requests 
        WHERE student_id = ? AND course_id = ? AND status = 'pending'
    ");
    $enrollmentQuery->execute([$student_id, $course_id, $student_id, $course_id]);

    if ($enrollmentQuery->fetch()) {
        $_SESSION['error'] = "You already have an active enrollment or pending request for this course";
        header("Location: enroll.php");
        exit();
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $_SESSION['error'] = "Error checking enrollment status";
    header("Location: index.php");
    exit();
}

// Get available classes for this course with seat availability
$classes = [];
try {
    $classesQuery = $pdo->prepare("
        SELECT cl.class_id, cl.semester, cl.year, 
               p.first_name, p.last_name, cl.room,
               (SELECT COUNT(*) FROM enrollments WHERE class_id = cl.class_id) as enrolled_count,
               cl.max_capacity
        FROM classes cl
        JOIN professors p ON cl.prof_id = p.prof_id
        WHERE cl.course_id = ?
        HAVING enrolled_count < max_capacity
        ORDER BY cl.semester, cl.year
    ");
    $classesQuery->execute([$course_id]);
    $classes = $classesQuery->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $_SESSION['error'] = "Error loading class sections";
}

$pageTitle = "Enroll in " . htmlspecialchars($course['course_name']);
include __DIR__ . '/../includes/header.php';
?>

<main class="container">
    <div class="header">
        <h1><i class="fas fa-user-plus"></i> Enroll in <?= htmlspecialchars($course['course_name']) ?></h1>
        <a href="enroll.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Courses</a>
    </div>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="enrollment-form">
        <h2><i class="fas fa-chalkboard-teacher"></i> Available Class Sections</h2>
        
        <?php if (!empty($classes)): ?>
            <form action="process_enrollment.php" method="POST">
                <input type="hidden" name="course_id" value="<?= $course_id ?>">
                <input type="hidden" name="course_name" value="<?= htmlspecialchars($course['course_name']) ?>">
                
                <div class="table-container">
                    <table class="course-table">
                        <thead>
                            <tr>
                                <th>Select</th>
                                <th>Semester</th>
                                <th>Year</th>
                                <th>Professor</th>
                                <th>Room</th>
                                <th>Availability</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($classes as $class): ?>
                            <tr>
                                <td>
                                    <input type="radio" name="class_id" 
                                           value="<?= $class['class_id'] ?>" required>
                                </td>
                                <td>
                                    <span class="semester-badge semester-<?= strtolower($class['semester']) ?>">
                                        <?= $class['semester'] ?>
                                    </span>
                                </td>
                                <td><?= $class['year'] ?></td>
                                <td><?= htmlspecialchars($class['first_name'] . ' ' . $class['last_name']) ?></td>
                                <td><?= $class['room'] ?></td>
                                <td>
                                    <div class="availability-container">
                                        <div class="availability-bar" style="width: <?= min(100, ($class['enrolled_count'] / $class['max_capacity']) * 100) ?>%"></div>
                                        <span class="availability-text">
                                            <?= ($class['max_capacity'] - $class['enrolled_count']) ?> of <?= $class['max_capacity'] ?> seats available
                                        </span>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="submit-btn">
                        <i class="fas fa-check"></i> Complete Enrollment
                    </button>
                    <a href="enroll.php" class="cancel-btn">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        <?php else: ?>
            <div class="empty-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>No available class sections for <?= htmlspecialchars($course['course_name']) ?>.</p>
                <p>Please contact the <?= htmlspecialchars($course['dept_name']) ?> department for assistance.</p>
                <a href="enroll.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Courses
                </a>
            </div>
        <?php endif; ?>
    </div>
</main>

<style>
    /* Enrollment Form Styles */
    .enrollment-form {
        background-color: white;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        margin-top: 20px;
    }
    
    .enrollment-form h2 {
        color: #2c3e50;
        margin-top: 0;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    /* Radio Buttons */
    input[type="radio"] {
        transform: scale(1.3);
        accent-color: #28a745;
    }
    
    /* Semester Badges */
    .semester-badge {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 15px;
        font-size: 14px;
        font-weight: 600;
    }
    
    .semester-fall {
        background-color: #fff3e0;
        color: #e65100;
    }
    
    .semester-spring {
        background-color: #e8f5e9;
        color: #2e7d32;
    }
    
    .semester-summer {
        background-color: #e3f2fd;
        color: #1565c0;
    }
    
    /* Availability Bar */
    .availability-container {
        position: relative;
        height: 24px;
        background-color: #f0f0f0;
        border-radius: 4px;
        overflow: hidden;
    }
    
    .availability-bar {
        position: absolute;
        height: 100%;
        background-color: #28a745;
        transition: width 0.3s ease;
    }
    
    .availability-text {
        position: absolute;
        width: 100%;
        text-align: center;
        font-size: 12px;
        line-height: 24px;
        color: #fff;
        text-shadow: 0 0 2px rgba(0,0,0,0.5);
    }
    
    /* Form Actions */
    .form-actions {
        display: flex;
        gap: 15px;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #e0e0e0;
    }
    
    .submit-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        background-color: #28a745;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.3s ease;
    }
    
    .submit-btn:hover {
        background-color: #218838;
        transform: translateY(-2px);
    }
    
    .cancel-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        background-color: #f8f9fa;
        color: #495057;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
        transition: all 0.3s ease;
    }
    
    .cancel-btn:hover {
        background-color: #e9ecef;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .header {
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
        }
        
        .course-table {
            font-size: 14px;
        }
        
        .submit-btn, .cancel-btn {
            padding: 6px 10px;
            font-size: 14px;
        }
        
        .form-actions {
            flex-direction: column;
            gap: 10px;
        }
        
        .availability-text {
            font-size: 10px;
        }
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>