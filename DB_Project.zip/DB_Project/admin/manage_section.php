<?php
session_start();
include '../config/db.php';
include '../includes/auth.php';

checkRole('admin');

// Handle section actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $course_id = $_POST['course_id'] ?? null;
    
    if ($_POST['action'] === 'add_section') {
        $prof_id = $_POST['prof_id'];
        $semester = $_POST['semester'];
        $year = $_POST['year'];
        $room = $_POST['room'];

        try {
            $stmt = $pdo->prepare("INSERT INTO classes 
                (course_id, prof_id, semester, year, room) 
                VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$course_id, $prof_id, $semester, $year, $room]);
            $_SESSION['success'] = "Class section added successfully!";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error adding section: " . $e->getMessage();
        }
    } 
    elseif ($_POST['action'] === 'delete_section') {
        $section_id = $_POST['section_id'];
        
        try {
            // First check if there are any enrollments
            $enrollment_check = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE class_id = ?");
            $enrollment_check->execute([$section_id]);
            $enrollment_count = $enrollment_check->fetchColumn();
            
            if ($enrollment_count > 0) {
                $_SESSION['error'] = "Cannot delete section with enrolled students";
            } else {
                $stmt = $pdo->prepare("DELETE FROM classes WHERE class_id = ?");
                $stmt->execute([$section_id]);
                $_SESSION['success'] = "Section deleted successfully!";
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error deleting section: " . $e->getMessage();
        }
    }
    
    header("Location: manage_sections.php?course_id=" . $course_id);
    exit();
}

$course_id = $_GET['course_id'] ?? null;

// Fetch course details if specific course is selected
$course = null;
$sections = [];
$professors = [];

if ($course_id) {
    // Get course details
    $stmt = $pdo->prepare("SELECT c.*, d.dept_name 
                         FROM courses c 
                         JOIN departments d ON c.dept_id = d.dept_id 
                         WHERE c.course_id = ?");
    $stmt->execute([$course_id]);
    $course = $stmt->fetch();
    
    if ($course) {
        // Get all sections for this course
        $stmt = $pdo->prepare("SELECT cl.*, p.first_name, p.last_name,
                             (SELECT COUNT(*) FROM enrollments WHERE class_id = cl.class_id) as student_count
                             FROM classes cl
                             JOIN professors p ON cl.prof_id = p.prof_id
                             WHERE cl.course_id = ?");
        $stmt->execute([$course_id]);
        $sections = $stmt->fetchAll();
        
        // Get professors from the same department
        $stmt = $pdo->prepare("SELECT * FROM professors WHERE dept_id = ?");
        $stmt->execute([$course['dept_id']]);
        $professors = $stmt->fetchAll();
    }
}

$pageTitle = "Manage Course Sections";
include '../includes/header.php';
?>

<main class="admin-container">
    <div class="admin-header">
        <h1>
            <i class="icon-book"></i> 
            <?= $course ? "Manage Sections: " . htmlspecialchars($course['course_name']) : "Manage Course Sections" ?>
        </h1>
        <a href="manage_course.php" class="btn-back">← Back to Courses</a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($_SESSION['success']) ?>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?= htmlspecialchars($_SESSION['error']) ?>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <?php if ($course_id && $course): ?>
        <div class="admin-card-container">
            <section class="admin-card">
                <h2><i class="icon-plus"></i> Add New Section</h2>
                <form method="POST" class="admin-form">
                    <input type="hidden" name="action" value="add_section">
                    <input type="hidden" name="course_id" value="<?= $course_id ?>">
                    
                    <div class="form-group">
                        <label for="prof_id">Professor</label>
                        <select id="prof_id" name="prof_id" required>
                            <option value="">Select professor</option>
                            <?php foreach ($professors as $prof): ?>
                                <option value="<?= htmlspecialchars($prof['prof_id']) ?>">
                                    <?= htmlspecialchars($prof['first_name'] . ' ' . $prof['last_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="semester">Semester</label>
                        <select id="semester" name="semester" required>
                            <option value="Fall">Fall</option>
                            <option value="Spring">Spring</option>
                            <option value="Summer">Summer</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="year">Year</label>
                        <input type="number" id="year" name="year" 
                               value="<?= date('Y') ?>" required min="2000" max="2100">
                    </div>
                    
                    <div class="form-group">
                        <label for="room">Room</label>
                        <input type="text" id="room" name="room" required placeholder="Enter room number">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="icon-save"></i> Add Section
                    </button>
                </form>
            </section>

            <section class="admin-card">
                <h2><i class="icon-list"></i> Existing Sections</h2>
                
                <?php if (!empty($sections)): ?>
                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Professor</th>
                                    <th>Semester</th>
                                    <th>Year</th>
                                    <th>Room</th>
                                    <th>Students</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sections as $section): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($section['first_name'] . ' ' . $section['last_name']) ?></td>
                                        <td>
                                            <span class="semester-badge semester-<?= strtolower($section['semester']) ?>">
                                                <?= htmlspecialchars($section['semester']) ?>
                                            </span>
                                        </td>
                                        <td><?= htmlspecialchars($section['year']) ?></td>
                                        <td><?= htmlspecialchars($section['room']) ?></td>
                                        <td><?= htmlspecialchars($section['student_count']) ?></td>
                                        <td class="actions">
                                            <form method="POST" onsubmit="return confirm('Are you sure you want to delete this section?')" style="display: inline;">
                                                <input type="hidden" name="action" value="delete_section">
                                                <input type="hidden" name="course_id" value="<?= $course_id ?>">
                                                <input type="hidden" name="section_id" value="<?= $section['class_id'] ?>">
                                                <button type="submit" class="btn btn-danger" <?= $section['student_count'] > 0 ? 'disabled title="Cannot delete section with students"' : '' ?>>
                                                    <i class="icon-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="icon-book-empty"></i>
                        <p>No sections found for this course</p>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    <?php else: ?>
        <div class="admin-card">
            <div class="empty-state">
                <i class="icon-info"></i>
                <p>Please select a course to manage its sections</p>
                <a href="manage_course.php" class="btn btn-primary">
                    <i class="icon-book"></i> View Courses
                </a>
            </div>
        </div>
    <?php endif; ?>
</main>

<style>
    /* Main Layout */
    .admin-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
    }
    
    .admin-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }
    
    .admin-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .admin-card-container {
        display: grid;
        gap: 2rem;
    }
    
    .admin-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 15px rgba(0,0,0,0.08);
        padding: 1.8rem;
    }
    
    .admin-card h2 {
        color: #3a4a6b;
        font-size: 1.4rem;
        margin-top: 0;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    /* Form Styles */
    .admin-form {
        display: grid;
        gap: 1.2rem;
    }
    
    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .form-group label {
        font-weight: 500;
        color: #3a4a6b;
        font-size: 0.95rem;
    }
    
    .form-group input,
    .form-group select {
        padding: 0.8rem 1rem;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }
    
    .form-group input:focus,
    .form-group select:focus {
        border-color: #4361ee;
        outline: none;
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
    }
    
    /* Table Styles */
    .table-responsive {
        overflow-x: auto;
    }
    
    .admin-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .admin-table th {
        background-color: #f8f9fa;
        color: #3a4a6b;
        padding: 0.8rem 1rem;
        text-align: left;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .admin-table td {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        vertical-align: middle;
    }
    
    .admin-table tr:last-child td {
        border-bottom: none;
    }
    
    /* Buttons */
    .btn {
        padding: 0.7rem 1.2rem;
        border-radius: 6px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        border: none;
    }
    
    .btn-primary {
        background-color: #4361ee;
        color: white;
    }
    
    .btn-primary:hover {
        background-color: #3a56d4;
        transform: translateY(-1px);
    }
    
    .btn-danger {
        background-color: #f8f9fa;
        color: #ef233c;
        border: 1px solid #eee;
    }
    
    .btn-danger:hover {
        background-color: #feeaea;
    }
    
    .btn-danger:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    
    .btn-back {
        color: #4361ee;
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
    }
    
    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 2rem;
        color: #7f8c8d;
    }
    
    /* Alerts */
    .alert {
        padding: 1rem;
        border-radius: 6px;
        margin-bottom: 1.5rem;
    }
    
    .alert-success {
        background-color: #e8f5e9;
        color: #388e3c;
        border-left: 4px solid #388e3c;
    }
    
    .alert-danger {
        background-color: #f8d7da;
        color: #721c24;
        border-left: 4px solid #dc3545;
    }
    
    /* Semester Badges */
    .semester-badge {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: 4px;
        font-size: 0.8rem;
        font-weight: 500;
    }
    
    .semester-fall {
        background-color: #fff3e0;
        color: #e65100;
    }
    
    .semester-spring {
        background-color: #e8f5e9;
        color: #2e7d32;
    }
    
    .semester-summer {
        background-color: #e3f2fd;
        color: #1565c0;
    }
    
    /* Icons (using Unicode) */
    .icon-book::before { content: "📚"; }
    .icon-plus::before { content: "➕"; }
    .icon-list::before { content: "📋"; }
    .icon-book-empty::before { content: "📭"; font-size: 2rem; opacity: 0.5; }
    .icon-save::before { content: "💾"; }
    .icon-trash::before { content: "🗑️"; }
    .icon-info::before { content: "ℹ️"; }
    
    @media (max-width: 768px) {
        .admin-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .admin-card {
            padding: 1.3rem;
        }
        
        .admin-table td, .admin-table th {
            padding: 0.5rem;
            font-size: 0.9rem;
        }
        
        .actions {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
    }
</style>

<?php include '../includes/footer.php'; ?>