<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$pdo = getDB();
$course_id = (int)$_GET['course_id'];

// Get enrollment data with department info
$stmt = $pdo->prepare("
    SELECT 
        c.course_name,
        d.dept_name,
        COUNT(DISTINCT e.student_id) AS total_students,
        GROUP_CONCAT(DISTINCT CONCAT(cl.semester, ' ', cl.year) ORDER BY cl.year) AS offerings
    FROM courses c
    JOIN departments d ON c.dept_id = d.dept_id
    LEFT JOIN classes cl ON c.course_id = cl.course_id
    LEFT JOIN enrollments e ON cl.class_id = e.class_id
    WHERE c.course_id = ?
    GROUP BY c.course_id
");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

$pageTitle = "Course Enrollment";
include __DIR__ . '/../includes/header.php';
?>

<main class="admin-container">
    <div class="admin-header">
        <h1>Course Enrollment Statistics</h1>
        <a href="manage_department.php" class="btn btn-back">
            <i class="icon-arrow-left"></i> Back to Departments
        </a>
    </div>

    <div class="stats-card">
        <div class="stat-item">
            <span class="stat-label">Department:</span>
            <span class="stat-value"><?= htmlspecialchars($course['dept_name']) ?></span>
        </div>
        <div class="stat-item">
            <span class="stat-label">Course Name:</span>
            <span class="stat-value"><?= htmlspecialchars($course['course_name']) ?></span>
        </div>
        <div class="stat-item">
            <span class="stat-label">Total Students Enrolled:</span>
            <span class="stat-value"><?= $course['total_students'] ?></span>
        </div>
        <div class="stat-item">
            <span class="stat-label">Course Offerings:</span>
            <span class="stat-value"><?= $course['offerings'] ?? 'N/A' ?></span>
        </div>
    </div>
</main>

<style>
    .stats-card {
        background: white;
        padding: 2rem;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .stat-item {
        margin-bottom: 1.5rem;
        padding: 1rem;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .stat-label {
        font-weight: 500;
        color: #2c3e50;
        min-width: 180px;
    }

    .stat-value {
        color: #4361ee;
        font-weight: bold;
        text-align: right;
        flex-grow: 1;
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>