<?php
session_start();
include '../config/db.php';
include '../includes/auth.php';

// Ensure only admin can access this page
checkRole('admin');

// Handle course approval
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'approve') {
    $course_id = $_POST['course_id'];

    $query = $pdo->prepare("UPDATE courses SET is_approved = 1 WHERE course_id = ?");
    $query->execute([$course_id]);

    $_SESSION['success'] = "Course approved successfully!";
    header("Location: approve.php");
    exit();
}

// Fetch unapproved courses
$query = $pdo->prepare("SELECT c.*, d.dept_name FROM courses c JOIN departments d ON c.dept_id = d.dept_id WHERE c.is_approved = 0");
$query->execute();
$courses = $query->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Approve Courses";
include '../includes/header.php';
?>

<main class="admin-container">
    <div class="admin-header">
        <h1><i class="icon-approval"></i> Approve Courses</h1>
        <a href="index.php" class="btn-back">← Back to Dashboard</a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($_SESSION['success']) ?>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <div class="admin-card">
        <h2><i class="icon-pending"></i> Pending Approval</h2>
        
        <?php if (!empty($courses)): ?>
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Course Name</th>
                            <th>Department</th>
                            <th>Credits</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($courses as $course): ?>
                            <tr>
                                <td><?= htmlspecialchars($course['course_id']) ?></td>
                                <td><?= htmlspecialchars($course['course_name']) ?></td>
                                <td><?= htmlspecialchars($course['dept_name']) ?></td>
                                <td><?= htmlspecialchars($course['credits']) ?></td>
                                <td class="actions">
                                    <form method="POST">
                                        <input type="hidden" name="action" value="approve">
                                        <input type="hidden" name="course_id" value="<?= $course['course_id'] ?>">
                                        <button type="submit" class="btn btn-success">
                                            <i class="icon-check"></i> Approve
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="icon-check-circle"></i>
                <p>No courses pending approval</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<style>
    /* Main Layout */
    .admin-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
    }
    
    .admin-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }
    
    .admin-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .admin-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 15px rgba(0,0,0,0.08);
        padding: 1.8rem;
    }
    
    .admin-card h2 {
        color: #3a4a6b;
        font-size: 1.4rem;
        margin-top: 0;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    /* Table Styles */
    .table-responsive {
        overflow-x: auto;
    }
    
    .admin-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .admin-table th {
        background-color: #f8f9fa;
        color: #3a4a6b;
        padding: 0.8rem 1rem;
        text-align: left;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .admin-table td {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        vertical-align: middle;
    }
    
    .admin-table tr:last-child td {
        border-bottom: none;
    }
    
    /* Buttons */
    .btn {
        padding: 0.7rem 1.2rem;
        border-radius: 6px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        border: none;
    }
    
    .btn-success {
        background-color: #4caf50;
        color: white;
    }
    
    .btn-success:hover {
        background-color: #3d8b40;
        transform: translateY(-1px);
    }
    
    .btn-back {
        color: #4361ee;
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
    }
    
    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 2rem;
        color: #7f8c8d;
    }
    
    .empty-state i {
        font-size: 2rem;
        opacity: 0.5;
        margin-bottom: 1rem;
        display: block;
    }
    
    /* Alerts */
    .alert {
        padding: 1rem;
        border-radius: 6px;
        margin-bottom: 1.5rem;
    }
    
    .alert-success {
        background-color: #e8f5e9;
        color: #388e3c;
        border-left: 4px solid #388e3c;
    }
    
    /* Icons (using Unicode) */
    .icon-approval::before { content: "✅"; }
    .icon-pending::before { content: "⏳"; }
    .icon-check::before { content: "✓"; }
    .icon-check-circle::before { content: "✔️"; }
    
    @media (max-width: 768px) {
        .admin-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .admin-card {
            padding: 1.3rem;
        }
    }
</style>

<?php include '../includes/footer.php'; ?>