<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$pdo = getDB();

// Handle department creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_dept'])) {
    $dept_name = trim($_POST['dept_name']);
    $building = trim($_POST['building']);
    $budget = (float)$_POST['budget'];

    try {
        $stmt = $pdo->prepare("
            INSERT INTO departments (dept_name, building, budget)
            VALUES (:name, :building, :budget)
        ");
        $stmt->execute([
            ':name' => $dept_name,
            ':building' => $building,
            ':budget' => $budget
        ]);
        $_SESSION['success'] = "Department created successfully!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error creating department: " . $e->getMessage();
    }
}

// Handle department deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_dept'])) {
    $dept_id = (int)$_POST['dept_id'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM departments WHERE dept_id = ?");
        $stmt->execute([$dept_id]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['success'] = "Department deleted successfully!";
        } else {
            $_SESSION['error'] = "Department not found!";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error deleting department: " . $e->getMessage();
    }
    
    header("Location: manage_department.php");
    exit();
}

// Get all departments with statistics
$departments = $pdo->query("
    SELECT 
        d.dept_id,
        d.dept_name,
        d.building,
        d.budget,
        COUNT(DISTINCT c.course_id) AS course_count,
        COUNT(DISTINCT e.student_id) AS student_count,
        d.created_at
    FROM departments d
    LEFT JOIN courses c ON d.dept_id = c.dept_id
    LEFT JOIN classes cl ON c.course_id = cl.course_id
    LEFT JOIN enrollments e ON cl.class_id = e.class_id
    GROUP BY d.dept_id
    ORDER BY d.dept_name
")->fetchAll(PDO::FETCH_ASSOC);

// Get courses for filtering
$allCourses = $pdo->query("
    SELECT c.dept_id, c.course_id, c.course_name 
    FROM courses c
    ORDER BY c.dept_id, c.course_name
")->fetchAll(PDO::FETCH_GROUP);

$pageTitle = "Manage Departments";
include __DIR__ . '/../includes/header.php';
?>

<main class="admin-container">
    <div class="admin-header">
        <h1><i class="icon-department"></i> Manage Departments</h1>
        <a href="/DB_project/index.php" class="btn btn-back">
            <i class="icon-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <i class="icon-error"></i> <?= htmlspecialchars($_SESSION['error']) ?>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <i class="icon-success"></i> <?= htmlspecialchars($_SESSION['success']) ?>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <div class="admin-card">
        <section class="create-section">
            <h2>Create New Department</h2>
            <form method="POST">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Department Name</label>
                        <input type="text" name="dept_name" required>
                    </div>
                    <div class="form-group">
                        <label>Building</label>
                        <input type="text" name="building">
                    </div>
                    <div class="form-group">
                        <label>Budget ($)</label>
                        <input type="number" name="budget" step="0.01" min="0">
                    </div>
                </div>
                <button type="submit" name="create_dept" class="btn btn-primary">
                    <i class="icon-add"></i> Create Department
                </button>
            </form>
        </section>

        <section class="department-list">
            <h2>Existing Departments</h2>
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Department Name</th>
                            <th>Building</th>
                            <th>Budget</th>
                            <th>Courses</th>
                            <th>Students</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($departments as $dept): ?>
                        <tr>
                            <td><?= $dept['dept_id'] ?></td>
                            <td><?= htmlspecialchars($dept['dept_name']) ?></td>
                            <td><?= htmlspecialchars($dept['building']) ?></td>
                            <td>$<?= number_format($dept['budget'], 2) ?></td>
                            <td><?= $dept['course_count'] ?></td>
                            <td><?= $dept['student_count'] ?></td>
                            <td><?= date('M j, Y', strtotime($dept['created_at'])) ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="edit_department.php?id=<?= $dept['dept_id'] ?>" class="btn btn-edit">
                                        <i class="icon-edit"></i> Edit
                                    </a>
                                    <form method="POST" class="delete-form">
                                        <input type="hidden" name="dept_id" value="<?= $dept['dept_id'] ?>">
                                        <button type="submit" name="delete_dept" class="btn btn-delete">
                                            <i class="icon-delete"></i> Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="course-stats">
            <h2>Course Enrollment Details</h2>
            <form method="GET" action="course_enrollment.php">
                <div class="form-grid">
                    <div class="form-group">
                        <label>Select Department:</label>
                        <select name="dept_id" id="departmentSelect" required>
                            <option value="">Choose Department</option>
                            <?php foreach ($departments as $dept): ?>
                            <option value="<?= $dept['dept_id'] ?>">
                                <?= htmlspecialchars($dept['dept_name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Select Course:</label>
                        <select name="course_id" id="courseSelect" required disabled>
                            <option value="">First choose a department</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="icon-stats"></i> Show Enrollment
                </button>
            </form>
        </section>
    </div>
</main>

<script>
// Course filtering logic
const courses = <?= json_encode($allCourses) ?>;
const deptSelect = document.getElementById('departmentSelect');
const courseSelect = document.getElementById('courseSelect');


// Corrected course filtering logic
deptSelect.addEventListener('change', function() {
    const deptId = this.value;
    courseSelect.innerHTML = '<option value="">First choose a department</option>';
    courseSelect.disabled = !deptId;

    if (deptId) {
        const deptCourses = courses[deptId] || [];
        if (deptCourses.length > 0) {
            deptCourses.forEach(course => {
                // CORRECTED: Remove [0] from course reference
                const option = new Option(course.course_name, course.course_id);
                courseSelect.add(option);
            });
        } else {
            const option = new Option('No courses in this department', '');
            option.disabled = true;
            courseSelect.add(option);
        }
    }
});
// Delete confirmation
document.querySelectorAll('.delete-form').forEach(form => {
    form.addEventListener('submit', (e) => {
        if (!confirm('Are you sure you want to delete this department? All related data will be permanently removed!')) {
            e.preventDefault();
        }
    });
});
</script>

<style>
.admin-container {
    padding: 2rem;
    max-width: 1200px;
    margin: 0 auto;
}

.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #eee;
}

.create-section {
    margin-bottom: 3rem;
    padding: 2rem;
    background: #f8f9fa;
    border-radius: 8px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    color: #2c3e50;
    font-weight: 500;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 0.8rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 1rem;
}

.admin-table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

.admin-table th,
.admin-table td {
    padding: 1rem;
    text-align: left;
    border-bottom: 1px solid #eee;
}

.admin-table th {
    background-color: #f8f9fa;
    font-weight: 600;
}

.action-buttons {
    display: flex;
    gap: 0.5rem;
}

.btn-edit {
    background-color: #17a2b8;
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-delete {
    background-color: #dc3545;
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.course-stats {
    margin-top: 3rem;
    padding: 2rem;
    background: #f8f9fa;
    border-radius: 8px;
}

@media (max-width: 768px) {
    .admin-header {
        flex-direction: column;
        gap: 1rem;
    }
    
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .action-buttons {
        flex-direction: column;
    }
}
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>