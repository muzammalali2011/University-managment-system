<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pdo = getDB();
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Handle approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {
        $request_id = (int)$_POST['request_id'];
        $action = $_POST['action'];
        if (!in_array($action, ['approve', 'reject'])) {
            throw new Exception("Invalid action specified");
        }
        $pdo->beginTransaction();
        $requestsQuery = $pdo->query("
    SELECT er.*, 
           s.first_name AS student_fname,
           s.last_name AS student_lname,
           c.course_name,
           p.first_name AS prof_fname,
           p.last_name AS prof_lname,
           cl.semester,
           cl.year,
           cl.room,
           cl.max_capacity,
           (SELECT COUNT(*) FROM enrollments WHERE class_id = cl.class_id) as current_enrollment
    FROM enrollment_requests er
    JOIN students s ON er.student_id = s.student_id
    JOIN courses c ON er.course_id = c.course_id
    JOIN professors p ON er.professor_id = p.prof_id
    JOIN classes cl ON er.class_id = cl.class_id
    WHERE er.status = 'pending'
    ORDER BY er.request_date DESC
");
        // Get full request details
        $requestQuery = $pdo->prepare("
            SELECT er.*, cl.class_id, cl.max_capacity
            FROM enrollment_requests er
            JOIN classes cl ON er.class_id = cl.class_id
            WHERE er.request_id = ?
        ");
        $requestQuery->execute([$request_id]);
        $request = $requestQuery->fetch();
        
        if (!$request) {
            throw new Exception("Invalid enrollment request");
        }
        
        if ($action === 'approve') {
            // Check current enrollment count
            $enrollmentCount = $pdo->prepare("
                SELECT COUNT(*) as count 
                FROM enrollments 
                WHERE class_id = ?
            ");
            $enrollmentCount->execute([$request['class_id']]);
            $count = $enrollmentCount->fetch()['count'];
            
            if ($count >= $request['max_capacity']) {
                throw new Exception("Class capacity reached for this section");
            }
            
            // Update request status
$updateRequest = $pdo->prepare("
UPDATE enrollment_requests 
SET status = ?, processed_date = NOW()
WHERE request_id = ?
");
            // Create actual enrollment
            $insertEnrollment = $pdo->prepare("
                INSERT INTO enrollments 
                (student_id, class_id, enrollment_date)
                VALUES (?, ?, NOW())
            ");
            $insertEnrollment->execute([
                $request['student_id'],
                $request['class_id']
            ]);
        }
        
        // Update request status
        $updateRequest = $pdo->prepare("
            UPDATE enrollment_requests 
            SET status = ?, processed_date = NOW()
            WHERE request_id = ?
        ");
        $updateRequest->execute([
            $action === 'approve' ? 'approved' : 'rejected',
            $request_id
        ]);
        
        $pdo->commit();
        $_SESSION['success'] = "Request successfully " . htmlspecialchars($action) . "ed";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = $e->getMessage();
    }
    header("Location: approve_enrollment.php");
    exit();
}

// Fetch pending requests with detailed information
try {
    $requestsQuery = $pdo->query("
        SELECT er.*, 
               s.first_name AS student_fname,
               s.last_name AS student_lname,
               c.course_name,
               p.first_name AS prof_fname,
               p.last_name AS prof_lname,
               cl.semester,
               cl.year,
               cl.room,
               cl.max_capacity,
               (SELECT COUNT(*) FROM enrollments WHERE class_id = cl.class_id) as current_enrollment
        FROM enrollment_requests er
        JOIN students s ON er.student_id = s.student_id
        JOIN courses c ON er.course_id = c.course_id
        JOIN professors p ON er.professor_id = p.prof_id
        JOIN classes cl ON er.class_id = cl.class_id
        WHERE er.status = 'pending'
        ORDER BY er.request_date DESC
    ");
    $requests = $requestsQuery->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $_SESSION['error'] = "Error loading enrollment requests";
}

$pageTitle = "Approve Enrollment Requests";
include __DIR__ . '/../includes/header.php';
?>

<main class="admin-container">
    <div class="admin-header">
        <h1><i class="icon-approval"></i> Approve Enrollment Requests</h1>
        <div class="admin-actions">
            <a href="index.php" class="btn-back">← Back to Dashboard</a>
        </div>
    </div>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error">
            <i class="icon-error"></i> <?= htmlspecialchars($_SESSION['error']) ?>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <i class="icon-success"></i> <?= htmlspecialchars($_SESSION['success']) ?>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <section class="admin-card">
        <h2><i class="icon-pending"></i> Pending Enrollment Requests</h2>
        
        <?php if (!empty($requests)): ?>
            <div class="table-responsive">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Course</th>
                            <th>Class Details</th>
                            <th>Professor</th>
                            <th>Request Date</th>
                            <th>Availability</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $request): ?>
                        <tr>
                            <td>
                                <div class="user-info">
                                    <span class="user-name"><?= htmlspecialchars($request['student_fname'] . ' ' . $request['student_lname']) ?></span>
                                    <span class="user-id">ID: <?= $request['student_id'] ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="course-info">
                                    <span class="course-name"><?= htmlspecialchars($request['course_name']) ?></span>
                                    <span class="course-id">ID: <?= $request['course_id'] ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="class-info">
                                    <span class="semester-badge semester-<?= strtolower($request['semester']) ?>">
                                        <?= $request['semester'] ?> <?= $request['year'] ?>
                                    </span>
                                    <span class="room">Room: <?= $request['room'] ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="prof-info">
                                    <span class="prof-name"><?= htmlspecialchars($request['prof_fname'] . ' ' . $request['prof_lname']) ?></span>
                                    <span class="prof-id">ID: <?= $request['professor_id'] ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="date-info">
                                    <?= date('M j, Y', strtotime($request['request_date'])) ?>
                                    <span class="time-info"><?= date('g:i a', strtotime($request['request_date'])) ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="availability-container">
                                    <div class="availability-bar" 
                                         style="width: <?= min(100, ($request['current_enrollment'] / $request['max_capacity']) * 100) ?>%"></div>
                                    <span class="availability-text">
                                        <?= $request['current_enrollment'] ?>/<?= $request['max_capacity'] ?>
                                    </span>
                                </div>
                            </td>
                            <td class="actions">
                                <form method="POST" class="action-form">
                                    <input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                                    <button type="submit" name="action" value="approve" class="btn btn-success">
                                        <i class="icon-check"></i> Approve
                                    </button>
                                    <button type="submit" name="action" value="reject" class="btn btn-danger">
                                        <i class="icon-close"></i> Reject
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="icon-check-circle"></i>
                <p>No pending enrollment requests found</p>
            </div>
        <?php endif; ?>
    </section>
</main>

<style>
    /* Main Container */
    .admin-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
    }
    
    /* Header */
    .admin-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }
    
    .admin-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    /* Cards */
    .admin-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 15px rgba(0,0,0,0.08);
        padding: 1.8rem;
    }
    
    .admin-card h2 {
        color: #3a4a6b;
        font-size: 1.4rem;
        margin-top: 0;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    /* Table */
    .table-responsive {
        overflow-x: auto;
    }
    
    .admin-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .admin-table th {
        background-color: #f8f9fa;
        color: #3a4a6b;
        padding: 0.8rem 1rem;
        text-align: left;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .admin-table td {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        vertical-align: middle;
    }
    
    /* Information Displays */
    .user-info, .course-info, .prof-info, .class-info, .date-info {
        display: flex;
        flex-direction: column;
    }
    
    .user-name, .course-name, .prof-name {
        font-weight: 500;
        margin-bottom: 0.2rem;
    }
    
    .user-id, .course-id, .prof-id, .room, .time-info {
        font-size: 0.8rem;
        color: #7f8c8d;
    }
    
    /* Semester Badges */
    .semester-badge {
        display: inline-block;
        padding: 0.3rem 0.6rem;
        border-radius: 15px;
        font-size: 0.8rem;
        font-weight: 500;
    }
    
    .semester-fall {
        background-color: #fff3e0;
        color: #e65100;
    }
    
    .semester-spring {
        background-color: #e8f5e9;
        color: #2e7d32;
    }
    
    .semester-summer {
        background-color: #e3f2fd;
        color: #1565c0;
    }
    
    /* Availability Bar */
    .availability-container {
        position: relative;
        height: 24px;
        background-color: #f0f0f0;
        border-radius: 4px;
        overflow: hidden;
    }
    
    .availability-bar {
        position: absolute;
        height: 100%;
        background-color: #28a745;
        transition: width 0.3s ease;
    }
    
    .availability-text {
        position: absolute;
        width: 100%;
        text-align: center;
        font-size: 12px;
        line-height: 24px;
        color: #fff;
        text-shadow: 0 0 2px rgba(0,0,0,0.5);
    }
    
    /* Action Buttons */
    .action-form {
        display: flex;
        gap: 0.5rem;
    }
    
    .btn {
        padding: 0.6rem 1rem;
        border-radius: 6px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        border: none;
        font-size: 0.9rem;
    }
    
    .btn-success {
        background-color: #28a745;
        color: white;
    }
    
    .btn-danger {
        background-color: #dc3545;
        color: white;
    }
    
    .btn-success:hover, .btn-danger:hover {
        transform: translateY(-1px);
        opacity: 0.9;
    }
    
    /* Alerts */
    .alert {
        padding: 1rem;
        border-radius: 6px;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .alert-success {
        background-color: #e8f5e9;
        color: #388e3c;
        border-left: 4px solid #388e3c;
    }
    
    .alert-error {
        background-color: #ffebee;
        color: #d32f2f;
        border-left: 4px solid #d32f2f;
    }
    
    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 2rem;
        color: #7f8c8d;
    }
    
    /* Icons */
    .icon-approval::before { content: "📝"; }
    .icon-pending::before { content: "⏳"; }
    .icon-check::before { content: "✓"; }
    .icon-close::before { content: "✗"; }
    .icon-check-circle::before { content: "✔️"; }
    .icon-error::before { content: "⚠️"; }
    .icon-success::before { content: "✓"; }
    
    /* Back Button */
    .btn-back {
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        padding: 0.5rem 1rem;
        background-color: #f8f9fa;
        color: #495057;
        text-decoration: none;
        border-radius: 6px;
        transition: all 0.3s ease;
    }
    
    .btn-back:hover {
        background-color: #e9ecef;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .admin-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .action-form {
            flex-direction: column;
        }
        
        .admin-card {
            padding: 1.3rem;
        }
        
        .admin-table th, 
        .admin-table td {
            padding: 0.5rem;
            font-size: 0.85rem;
        }
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>