<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$pdo = getDB();

// Get department ID from URL
$dept_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch department details
$stmt = $pdo->prepare("
    SELECT dept_id, dept_name, building, budget 
    FROM departments 
    WHERE dept_id = ?
");
$stmt->execute([$dept_id]);
$department = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_dept'])) {
    $dept_name = trim($_POST['dept_name']);
    $building = trim($_POST['building']);
    $budget = (float)$_POST['budget'];

    try {
        $stmt = $pdo->prepare("
            UPDATE departments 
            SET dept_name = :name,
                building = :building,
                budget = :budget,
                updated_at = NOW()
            WHERE dept_id = :id
        ");
        $stmt->execute([
            ':name' => $dept_name,
            ':building' => $building,
            ':budget' => $budget,
            ':id' => $dept_id
        ]);
        
        $_SESSION['success'] = "Department updated successfully!";
        header("Location: manage_department.php");
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error updating department: " . $e->getMessage();
    }
}

// Redirect if invalid department
if (!$department) {
    $_SESSION['error'] = "Department not found";
    header("Location: manage_department.php");
    exit();
}

$pageTitle = "Edit Department";
include __DIR__ . '/../includes/header.php';
?>

<main class="admin-container">
    <div class="admin-header">
        <h1><i class="icon-edit"></i> Edit Department</h1>
        <a href="manage_department.php" class="btn btn-back">
            <i class="icon-arrow-left"></i> Back to Departments
        </a>
    </div>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <i class="icon-error"></i> <?= htmlspecialchars($_SESSION['error']) ?>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="admin-card">
        <form method="POST">
            <div class="form-grid">
                <div class="form-group">
                    <label>Department Name *</label>
                    <input type="text" name="dept_name" 
                        value="<?= htmlspecialchars($department['dept_name']) ?>" 
                        required>
                </div>
                
                <div class="form-group">
                    <label>Building</label>
                    <input type="text" name="building" 
                        value="<?= htmlspecialchars($department['building']) ?>">
                </div>
                
                <div class="form-group">
                    <label>Budget ($)</label>
                    <input type="number" name="budget" step="0.01" min="0"
                        value="<?= htmlspecialchars($department['budget']) ?>">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" name="update_dept" class="btn btn-primary">
                    <i class="icon-save"></i> Save Changes
                </button>
                <a href="manage_department.php" class="btn btn-secondary">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</main>

<style>
    /* Inherits main admin styles, additions below */
    .form-actions {
        margin-top: 2rem;
        display: flex;
        gap: 1rem;
        padding-top: 1.5rem;
        border-top: 1px solid #eee;
    }

    .admin-card {
        background: white;
        padding: 2rem;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .form-group input {
        background: #fff;
        transition: border-color 0.3s ease;
    }

    .form-group input:focus {
        border-color: #4361ee;
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
    }

    @media (max-width: 768px) {
        .form-grid {
            grid-template-columns: 1fr;
        }
        
        .form-actions {
            flex-direction: column;
        }
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>