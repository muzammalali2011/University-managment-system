<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pageTitle = "Admin Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<main class="admin-dashboard">
    <div class="dashboard-header">
        <h1>Admin Dashboard</h1>
        <p class="welcome-msg">Welcome back, <?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></p>
    </div>
    
    <div class="admin-actions">
        <a href="manage_user.php" class="action-card">
            <div class="card-icon">
                <img src="../assets/images/icons/user-management.png" alt="User Management">
            </div>
            <h3>Manage Users</h3>
            <p>Create, edit, and manage system users</p>
        </a>
        
        <a href="manage_course.php" class="action-card">
            <div class="card-icon">
                <img src="../assets/images/icons/course-management.png" alt="Course Management">
            </div>
            <h3>Manage Courses</h3>
            <p>Add, edit, and organize courses</p>
        </a>
        
        <a href="approve.php" class="action-card">
            <div class="card-icon">
                <img src="../assets/images/icons/course-approval.png" alt="Course Approval">
            </div>
            <h3>Approve Courses</h3>
            <p>Review and approve new courses</p>
        </a>
        
        <a href="approve_enrollment.php" class="action-card">
            <div class="card-icon">
                <img src="../assets/images/icons/enrollment-approval.png" alt="Enrollment Approval">
            </div>
            <h3>Approve Enrollments</h3>
            <p>Manage student course enrollments</p>
        </a>
        
        <!-- New Department Management Card -->
        <a href="manage_department.php" class="action-card">
            <div class="card-icon">
                <img src="../assets/images/icons/manage_department.png" alt="Department Management">
            </div>
            <h3>Manage Departments</h3>
            <p>Create and manage academic departments</p>
        </a>
    </div>
</main>

<style>
    .admin-dashboard {
        padding: 2rem;
        max-width: 1200px;
        margin: 0 auto;
    }
    
    .dashboard-header {
        text-align: center;
        margin-bottom: 3rem;
        padding-top: 1rem;
    }
    
    .dashboard-header h1 {
        color: #2c3e50;
        font-size: 2.2rem;
        margin-bottom: 0.5rem;
    }
    
    .welcome-msg {
        color: #7f8c8d;
        font-size: 1.1rem;
    }
    
    .admin-actions {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
    }
    
    .action-card {
        background: white;
        border-radius: 10px;
        padding: 1.8rem;
        text-align: center;
        text-decoration: none;
        color: #2c3e50;
        transition: all 0.3s ease;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border: 1px solid #e0e0e0;
    }
    
    .action-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }
    
    .card-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 1.5rem;
        background: #f8f9fa;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 1rem;
    }
    
    .card-icon img {
        max-width: 100%;
        max-height: 100%;
    }
    
    .action-card h3 {
        margin-bottom: 0.8rem;
        font-size: 1.3rem;
    }
    
    .action-card p {
        color: #7f8c8d;
        font-size: 0.95rem;
        line-height: 1.5;
    }
    
    @media (max-width: 768px) {
        .admin-actions {
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        }
    }
    
    @media (max-width: 480px) {
        .admin-actions {
            grid-template-columns: 1fr;
        }
        
        .dashboard-header {
            margin-bottom: 2rem;
        }
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>