<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pdo = getDB();

// Handle user addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        try {
            $pdo->beginTransaction();
            
            $username = $_POST['username'];
            $password = $_POST['password'];
            $role = $_POST['role'];
            $associated_id = 0;

            // Handle professor creation
            if ($role === 'professor') {
                $stmt = $pdo->prepare("
                    INSERT INTO professors (first_name, last_name, email, hire_date, dept_id, salary)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $_POST['prof_first_name'],
                    $_POST['prof_last_name'],
                    $_POST['prof_email'],
                    $_POST['prof_hire_date'],
                    $_POST['prof_dept_id'],
                    $_POST['prof_salary']
                ]);
                $associated_id = $pdo->lastInsertId();
            }
            // Handle student creation
            elseif ($role === 'student') {
                $stmt = $pdo->prepare("
                    INSERT INTO students (first_name, last_name, email, enrollment_date, dept_id)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $_POST['student_first_name'],
                    $_POST['student_last_name'],
                    $_POST['student_email'],
                    $_POST['student_enrollment_date'],
                    $_POST['student_dept_id']
                ]);
                $associated_id = $pdo->lastInsertId();
            }
            // For admin, use existing associated_id
            else {
                $associated_id = (int)$_POST['associated_id'];
            }

            // Create user account
            $query = $pdo->prepare("INSERT INTO users (username, password, role, associated_id) VALUES (?, ?, ?, ?)");
            $query->execute([$username, $password, $role, $associated_id]);
            
            $pdo->commit();
            $_SESSION['success'] = "User added successfully!";
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("User add error: " . $e->getMessage());
            $_SESSION['error'] = "Failed to add user. " . (strpos($e->getMessage(), 'Duplicate entry') ? "Username may already exist." : "Please check all fields.");
        }
    }
    elseif ($_POST['action'] === 'delete') {
        try {
            $user_id = (int)$_POST['user_id'];
            $query = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
            $query->execute([$user_id]);
            $_SESSION['success'] = "User deleted successfully!";
        } catch (PDOException $e) {
            error_log("User delete error: " . $e->getMessage());
            $_SESSION['error'] = "Failed to delete user.";
        }
    }
    header("Location: manage_user.php");
    exit();
}

// Fetch all users with additional info
$users = [];
try {
    $query = $pdo->query("
        SELECT u.*, 
               CASE 
                   WHEN u.role = 'professor' THEN CONCAT(p.first_name, ' ', p.last_name)
                   WHEN u.role = 'student' THEN CONCAT(s.first_name, ' ', s.last_name)
                   ELSE 'Admin'
               END as full_name
        FROM users u
        LEFT JOIN professors p ON u.associated_id = p.prof_id AND u.role = 'professor'
        LEFT JOIN students s ON u.associated_id = s.student_id AND u.role = 'student'
        ORDER BY u.user_id DESC
    ");
    $users = $query->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Users fetch error: " . $e->getMessage());
    $_SESSION['error'] = "Failed to load users.";
}

// Get departments for forms
$departments = [];
try {
    $query = $pdo->query("SELECT dept_id, dept_name FROM departments ORDER BY dept_name");
    $departments = $query->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Departments fetch error: " . $e->getMessage());
}

$pageTitle = "Manage Users";
include __DIR__ . '/../includes/header.php';
?>

<main class="admin-container">
    <div class="admin-header">
        <h1>User Management</h1>
        <div class="admin-actions">
            <a href="index.php" class="btn-back">← Back to Dashboard</a>
        </div>
    </div>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <div class="admin-card-container">
        <section class="admin-card">
            <h2><i class="icon-user-add"></i> Add New User</h2>
            <form method="POST" class="admin-form" id="userForm">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required 
                           placeholder="Enter username">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required 
                           placeholder="Enter password">
                </div>
                
                <div class="form-group">
                    <label for="role">Role</label>
                    <select id="role" name="role" required onchange="toggleRoleFields()">
                        <option value="">Select role</option>
                        <option value="admin">Admin</option>
                        <option value="professor">Professor</option>
                        <option value="student">Student</option>
                    </select>
                </div>
                
                <!-- Admin ID field -->
                <div class="form-group" id="adminIdField" style="display: none;">
                    <label for="associated_id">Admin ID</label>
                    <input type="number" id="associated_id" name="associated_id" 
                           placeholder="Enter admin ID">
                </div>
                
                <!-- Professor fields -->
                <div id="professorFields" style="display: none;">
                    <div class="form-group">
                        <label for="prof_first_name">First Name</label>
                        <input type="text" id="prof_first_name" name="prof_first_name" 
                               placeholder="Professor first name">
                    </div>
                    
                    <div class="form-group">
                        <label for="prof_last_name">Last Name</label>
                        <input type="text" id="prof_last_name" name="prof_last_name" 
                               placeholder="Professor last name">
                    </div>
                    
                    <div class="form-group">
                        <label for="prof_email">Email</label>
                        <input type="email" id="prof_email" name="prof_email" 
                               placeholder="Professor email">
                    </div>
                    
                    <div class="form-group">
                        <label for="prof_hire_date">Hire Date</label>
                        <input type="date" id="prof_hire_date" name="prof_hire_date">
                    </div>
                    
                    <div class="form-group">
                        <label for="prof_dept_id">Department</label>
                        <select id="prof_dept_id" name="prof_dept_id">
                            <option value="">Select department</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?= $dept['dept_id'] ?>"><?= htmlspecialchars($dept['dept_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="prof_salary">Salary</label>
                        <input type="number" step="0.01" id="prof_salary" name="prof_salary" 
                               placeholder="Enter salary">
                    </div>
                </div>
                
                <!-- Student fields -->
                <div id="studentFields" style="display: none;">
                    <div class="form-group">
                        <label for="student_first_name">First Name</label>
                        <input type="text" id="student_first_name" name="student_first_name" 
                               placeholder="Student first name">
                    </div>
                    
                    <div class="form-group">
                        <label for="student_last_name">Last Name</label>
                        <input type="text" id="student_last_name" name="student_last_name" 
                               placeholder="Student last name">
                    </div>
                    
                    <div class="form-group">
                        <label for="student_email">Email</label>
                        <input type="email" id="student_email" name="student_email" 
                               placeholder="Student email">
                    </div>
                    
                    <div class="form-group">
                        <label for="student_enrollment_date">Enrollment Date</label>
                        <input type="date" id="student_enrollment_date" name="student_enrollment_date">
                    </div>
                    
                    <div class="form-group">
                        <label for="student_dept_id">Department</label>
                        <select id="student_dept_id" name="student_dept_id">
                            <option value="">Select department</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?= $dept['dept_id'] ?>"><?= htmlspecialchars($dept['dept_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="icon-save"></i> Add User
                </button>
            </form>
        </section>

        <section class="admin-card">
            <h2><i class="icon-users"></i> Existing Users</h2>
            
            <?php if (!empty($users)): ?>
                <div class="table-responsive">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Name</th>
                                <th>Associated ID</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?= htmlspecialchars($user['user_id']) ?></td>
                                    <td><?= htmlspecialchars($user['username']) ?></td>
                                    <td><span class="role-badge role-<?= htmlspecialchars($user['role']) ?>">
                                        <?= htmlspecialchars($user['role']) ?>
                                    </span></td>
                                    <td><?= htmlspecialchars($user['full_name'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($user['associated_id']) ?></td>
                                    <td class="actions">
                                        <form method="POST" onsubmit="return confirm('Are you sure?')">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                                            <button type="submit" class="btn btn-danger">
                                                <i class="icon-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="icon-users-empty"></i>
                    <p>No users found</p>
                </div>
            <?php endif; ?>
        </section>
    </div>
</main>

<script>
function toggleRoleFields() {
    const role = document.getElementById('role').value;
    const professorFields = document.getElementById('professorFields');
    const studentFields = document.getElementById('studentFields');
    const adminIdField = document.getElementById('adminIdField');

    // Show/hide sections
    professorFields.style.display = role === 'professor' ? 'block' : 'none';
    studentFields.style.display = role === 'student' ? 'block' : 'none';
    adminIdField.style.display = role === 'admin' ? 'block' : 'none';

    // Clear fields when switching roles
    if (role === 'professor') {
        studentFields.querySelectorAll('input, select').forEach(field => field.value = '');
    } else if (role === 'student') {
        professorFields.querySelectorAll('input, select').forEach(field => field.value = '');
    }
}

document.getElementById('userForm').addEventListener('submit', function(e) {
    const role = document.getElementById('role').value;
    const requiredFields = {
        'professor': ['prof_first_name', 'prof_last_name', 'prof_email', 'prof_hire_date', 'prof_dept_id'],
        'student': ['student_first_name', 'student_last_name', 'student_email', 'student_enrollment_date', 'student_dept_id']
    };

    if (requiredFields[role]) {
        for (const fieldId of requiredFields[role]) {
            const field = document.getElementById(fieldId);
            if (!field.value.trim()) {
                alert(`Missing required field: ${field.labels[0].textContent}`);
                e.preventDefault();
                return;
            }
        }
    }
});
</script>

<style>
    /* Your existing CSS remains unchanged */
    .admin-container { max-width: 1200px; margin: 0 auto; padding: 2rem 1.5rem; }
    .admin-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
    .admin-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
    }
    
    .admin-card-container {
        display: grid;
        gap: 2rem;
    }
    .admin-card { background: white; border-radius: 10px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); padding: 1.8rem; }
    /* ... rest of your existing styles ... */
    .admin-card h2 {
        color: #3a4a6b;
        font-size: 1.4rem;
        margin-top: 0;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    /* Form Styles */
    .admin-form {
        display: grid;
        gap: 1.2rem;
    }
    
    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .form-group label {
        font-weight: 500;
        color: #3a4a6b;
        font-size: 0.95rem;
    }
    
    .form-group input,
    .form-group select {
        padding: 0.8rem 1rem;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }
    
    .form-group input:focus,
    .form-group select:focus {
        border-color: #4361ee;
        outline: none;
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
    }
    
    .form-hint {
        color: #7f8c8d;
        font-size: 0.85rem;
    }
    
    /* Table Styles */
    .table-responsive {
        overflow-x: auto;
    }
    
    .admin-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .admin-table th {
        background-color: #f8f9fa;
        color: #3a4a6b;
        padding: 0.8rem 1rem;
        text-align: left;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .admin-table td {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        vertical-align: middle;
    }
    
    .admin-table tr:last-child td {
        border-bottom: none;
    }
    
    /* Role Badges */
    .role-badge {
        display: inline-block;
        padding: 0.3rem 0.6rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
    }
    
    .role-admin {
        background-color: #e3f2fd;
        color: #1976d2;
    }
    
    .role-professor {
        background-color: #e8f5e9;
        color: #388e3c;
    }
    
    .role-student {
        background-color: #fff3e0;
        color: #ef6c00;
    }
    
    /* Buttons */
    .btn {
        padding: 0.7rem 1.2rem;
        border-radius: 6px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        border: none;
    }
    
    .btn-primary {
        background-color: #4361ee;
        color: white;
    }
    
    .btn-primary:hover {
        background-color: #3a56d4;
        transform: translateY(-1px);
    }
    
    .btn-danger {
        background-color: #f8f9fa;
        color: #ef233c;
        border: 1px solid #eee;
    }
    
    .btn-danger:hover {
        background-color: #feeaea;
    }
    
    .btn-back {
        color: #4361ee;
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
    }
    
    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 2rem;
        color: #7f8c8d;
    }
    
    /* Alerts */
    .alert {
        padding: 1rem;
        border-radius: 6px;
        margin-bottom: 1.5rem;
    }
    
    .alert-error {
        background-color: #feeaea;
        color: #ef233c;
        border-left: 4px solid #ef233c;
    }
    
    .alert-success {
        background-color: #e8f5e9;
        color: #388e3c;
        border-left: 4px solid #388e3c;
    }
    
    /* Icons (using Unicode) */
    .icon-user-add::before { content: "👤"; }
    .icon-users::before { content: "👥"; }
    .icon-users-empty::before { content: "🕳️"; font-size: 2rem; opacity: 0.5; }
    .icon-save::before { content: "💾"; }
    .icon-trash::before { content: "🗑️"; }
    
    @media (max-width: 768px) {
        .admin-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .admin-card {
            padding: 1.3rem;
        }
    }

</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>