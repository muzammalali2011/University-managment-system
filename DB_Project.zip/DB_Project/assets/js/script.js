// Confirm before deleting an item
document.addEventListener('DOMContentLoaded', () => {
    const deleteButtons = document.querySelectorAll('button[data-delete]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            const confirmDelete = confirm('Are you sure you want to delete this item?');
            if (!confirmDelete) {
                event.preventDefault();
            }
        });
    });
});

// Toggle visibility of success or error messages
document.addEventListener('DOMContentLoaded', () => {
    const messages = document.querySelectorAll('p[style="color: green;"], p[style="color: red;"]');
    setTimeout(() => {
        messages.forEach(message => {
            message.style.display = 'none';
        });
    }, 5000); // Hide messages after 5 seconds
});