<?php
require_once __DIR__ . '/includes/auth.php';

if (!isLoggedIn()) {
    header("Location: " . BASE_PATH . "/login.php");
    exit;
}

// Redirect to appropriate dashboard based on role
if (isLoggedIn()) {
    switch ($_SESSION['role']) {
        case 'admin':
            header("Location: " . ADMIN_PATH . "/index.php");
            break;
        case 'professor':
            header("Location: " . PROFESSOR_PATH . "/index.php");
            break;
        case 'student':
            header("Location: " . STUDENT_PATH . "/index.php");
            break;
        default:
            header("Location: " . BASE_PATH . "/login.php");
    }
    exit;
}

$pageTitle = "University Management System";
include __DIR__ . '/includes/header.php';
?>

<!-- This content will only show if redirects fail -->
<main>
    <h1>Welcome to University Management System</h1>
    <p>Please <a href="<?= BASE_PATH ?>/login.php">login</a> to continue.</p>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>