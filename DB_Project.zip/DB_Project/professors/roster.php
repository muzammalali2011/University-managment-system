<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
requireRole('professor');
ensureProfessorContext();

$class_id = $_GET['class_id'] ?? null;
if (!$class_id) {
    header("Location: courses.php?error=missing_class");
    exit();
}

// Verify professor teaches this class
$stmt = $pdo->prepare("
    SELECT c.course_name, cl.semester, cl.year 
    FROM classes cl
    JOIN courses c ON cl.course_id = c.course_id
    WHERE cl.class_id = ? AND cl.prof_id = ?
");
$stmt->execute([$class_id, getAssociatedId()]);
$classInfo = $stmt->fetch();

if (!$classInfo) {
    header("Location: courses.php?error=unauthorized");
    exit();
}

// Get enrolled students with calculated grades
$stmt = $pdo->prepare("
    SELECT 
        s.student_id, 
        s.first_name, 
        s.last_name,
        e.total_mark,
        e.letter_grade
    FROM enrollments e
    JOIN students s ON e.student_id = s.student_id
    WHERE e.class_id = ?
    ORDER BY s.last_name, s.first_name
");
$stmt->execute([$class_id]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Class Roster";
include __DIR__ . '/../includes/header.php';
?>

<main class="professor-container">
    <div class="professor-header">
        <div>
            <h1><i class="icon-roster"></i> Class Roster</h1>
            <p class="class-info">
                <?= htmlspecialchars($classInfo['course_name']) ?> • 
                <?= htmlspecialchars($classInfo['semester']) ?> <?= htmlspecialchars($classInfo['year']) ?>
            </p>
        </div>
        <div class="header-actions">
            <a href="courses.php" class="btn-back">
                <i class="icon-back"></i> Back to Courses
            </a>
        </div>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success">
            <i class="icon-success"></i> Grades updated successfully!
        </div>
    <?php endif; ?>

    <div class="professor-card">
        <?php if (empty($students)): ?>
            <div class="empty-state">
                <i class="icon-warning"></i>
                <p>No students enrolled in this class.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="professor-table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Total Marks</th>
                            <th>Final Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                        <tr>
                            <td><?= htmlspecialchars($student['student_id']) ?></td>
                            <td>
                                <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
                            </td>
                            <td><?= $student['total_mark'] ?? 'N/A' ?></td>
                            <td class="grade-<?= strtolower($student['letter_grade'] ?? '') ?>">
                                <?= $student['letter_grade'] ?? 'N/A' ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        
        <div class="form-actions">
            <a href="grades.php?class_id=<?= $class_id ?>" class="btn btn-primary">
                <i class="icon-edit"></i> Enter/Update Grades
            </a>
            <a href="courses.php" class="btn btn-secondary">
                <i class="icon-courses"></i> Back to Courses
            </a>
        </div>
    </div>
</main>

<style>
    .grade-a { color: #2ecc71; }
    .grade-a- { color: #27ae60; }
    .grade-b { color: #f1c40f; }
    .grade-b- { color: #f39c12; }
    .grade-c { color: #e67e22; }
    .grade-f { color: #e74c3c; }
    
    /* Add to existing styles */
    </style>
<style>
    /* Reuse professor container styles */
    .professor-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
    }
    
    .professor-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #eee;
    }
    
    .professor-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0 0 0.3rem 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .class-info {
        color: #7f8c8d;
        margin: 0;
        font-size: 1rem;
    }
    
    .btn-back {
        color: #4361ee;
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        transition: all 0.3s ease;
    }
    
    .btn-back:hover {
        background-color: #f0f4ff;
    }
    
    /* Card Styles */
    .professor-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 15px rgba(0,0,0,0.08);
        padding: 1.5rem;
    }
    
    /* Table Styles */
    .table-responsive {
        overflow-x: auto;
        margin-bottom: 1.5rem;
    }
    
    .professor-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .professor-table th {
        background-color: #f8f9fa;
        color: #3a4a6b;
        padding: 0.8rem 1rem;
        text-align: left;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .professor-table td {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        vertical-align: middle;
    }
    
    .professor-table tr:last-child td {
        border-bottom: none;
    }
    
    /* Grade Status */
    .grade-present {
        color: #388e3c;
        font-weight: 500;
    }
    
    .grade-missing {
        color: #e53935;
        font-style: italic;
    }
    
    /* Form Actions */
    .form-actions {
        display: flex;
        gap: 0.8rem;
        padding-top: 1rem;
        border-top: 1px solid #eee;
    }
    
    /* Buttons */
    .btn {
        padding: 0.7rem 1.2rem;
        border-radius: 6px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        border: none;
        text-decoration: none;
        font-size: 0.9rem;
    }
    
    .btn-primary {
        background-color: #4361ee;
        color: white;
    }
    
    .btn-secondary {
        background-color: #f8f9fa;
        color: #3a4a6b;
        border: 1px solid #ddd;
    }
    
    .btn:hover {
        opacity: 0.9;
        transform: translateY(-1px);
    }
    
    /* Alert */
    .alert {
        padding: 1rem;
        border-radius: 6px;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .alert-success {
        background-color: #e8f5e9;
        color: #388e3c;
        border-left: 4px solid #388e3c;
    }
    
    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 3rem;
        color: #7f8c8d;
    }
    
    .empty-state i {
        font-size: 2.5rem;
        opacity: 0.5;
        margin-bottom: 1rem;
        display: block;
    }
    
    /* Icons */
    .icon-roster::before { content: "👥"; }
    .icon-back::before { content: "←"; }
    .icon-success::before { content: "✓"; }
    .icon-warning::before { content: "⚠️"; }
    .icon-edit::before { content: "✏️"; }
    .icon-courses::before { content: "📚"; }
    
    @media (max-width: 768px) {
        .professor-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .header-actions {
            width: 100%;
            justify-content: flex-end;
        }
        
        .form-actions {
            flex-direction: column;
        }
        
        .btn {
            width: 100%;
            justify-content: center;
        }
    }
    .professor-table td[data-grade] {
        font-weight: bold;
        text-align: center;
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>