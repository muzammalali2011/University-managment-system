// Add error reporting at the top
error_reporting(E_ALL);
ini_set('display_errors', 1);
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
requireRole('professor');
ensureProfessorContext();

$professor_id = $_SESSION['associated_id']; // Get professor's ID

// Get professor's courses with class_id
$stmt = $pdo->prepare("
    SELECT cl.class_id, c.course_name 
    FROM classes cl
    JOIN courses c ON cl.course_id = c.course_id
    WHERE cl.prof_id = ?
    ORDER BY cl.year DESC, cl.semester
");

// Show pending enrollment requests FOR THIS PROFESSOR
try {
    $pendingRequests = $pdo->prepare("
        SELECT er.request_id, c.course_name, cl.semester, cl.year,
               s.first_name AS student_fname, s.last_name AS student_lname
        FROM enrollment_requests er
        JOIN courses c ON er.course_id = c.course_id
        JOIN classes cl ON er.class_id = cl.class_id
        JOIN students s ON er.student_id = s.student_id
        WHERE er.professor_id = ? AND er.status = 'pending'
    ");
    $pendingRequests->execute([$professor_id]); // Use professor's ID
    $requests = $pendingRequests->fetchAll();
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $requests = [];
}

$stmt->execute([$professor_id]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

$courseCount = count($courses);
$firstClassId = $courseCount > 0 ? $courses[0]['class_id'] : null;

// Get professor's name with proper fallbacks
$profName = $_SESSION['first_name'] ?? 'Professor';
$username = $_SESSION['username'] ?? '';

$pageTitle = "Professor Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<!-- Rest of your HTML remains the same -->
<main class="professor-container">
    <div class="professor-header">
        <h1><i class="icon-welcome"></i> Welcome, <?= htmlspecialchars($profName) ?> <small>(<?= htmlspecialchars($username) ?>)</small></h1>
        <div class="header-actions">
            <a href="../logout.php" class="btn-logout"><i class="icon-logout"></i> Logout</a>
        </div>
    </div>
    
    <div class="dashboard-alert">
        <i class="icon-courses"></i> You have <strong><?= $courseCount ?></strong> active courses this semester.
    </div>
    
    <div class="dashboard-grid">
        <div class="dashboard-card">
            <div class="card-icon course-icon">
                <i class="icon-book"></i>
            </div>
            <div class="card-content">
                <h3>My Courses</h3>
                <p>View and manage your assigned courses</p>
                <a href="courses.php" class="btn btn-primary">
                    <i class="icon-view"></i> View Courses
                </a>
            </div>
        </div>
        
        <div class="dashboard-card">
            <div class="card-icon grade-icon">
                <i class="icon-grade"></i>
            </div>
            <div class="card-content">
                <h3>Grade Students</h3>
                <p>Enter and update student grades</p>
                <a href="<?= $firstClassId ? 'grades.php?class_id='.$firstClassId : '#' ?>" 
                   class="btn btn-success <?= !$firstClassId ? 'disabled' : '' ?>">
                    <i class="icon-edit"></i> Enter Grades
                </a>
            </div>
        </div>
        
        <div class="dashboard-card">
            <div class="card-icon roster-icon">
                <i class="icon-roster"></i>
            </div>
            <div class="card-content">
                <h3>Class Roster</h3>
                <p>View your class enrollments</p>
                <a href="<?= $firstClassId ? 'roster.php?class_id='.$firstClassId : '#' ?>" 
                   class="btn btn-info <?= !$firstClassId ? 'disabled' : '' ?>">
                    <i class="icon-list"></i> View Roster
                </a>
            </div>
        </div>
    </div>
</main>

<style>
    /* Main Container */
    .professor-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
    }
    
    /* Header Styles */
    .professor-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #eee;
    }
    
    .professor-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .professor-header h1 small {
        font-size: 1rem;
        color: #7f8c8d;
        font-weight: normal;
    }
    
    .header-actions {
        display: flex;
        gap: 1rem;
    }
    
    .btn-logout {
        color: #e74c3c;
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        transition: all 0.3s ease;
    }
    
    .btn-logout:hover {
        background-color: #ffebee;
    }
    
    /* Alert */
    .dashboard-alert {
        background-color: #e3f2fd;
        color: #1976d2;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 2rem;
        display: flex;
        align-items: center;
        gap: 0.8rem;
        font-size: 1.1rem;
    }
    
    /* Dashboard Grid */
    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
    }
    
    /* Cards */
    .dashboard-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        display: flex;
        flex-direction: column;
    }
    
    .dashboard-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    
    .card-icon {
        padding: 1.5rem;
        display: flex;
        justify-content: center;
        font-size: 2.5rem;
    }
    
    .course-icon { background-color: #e3f2fd; color: #1976d2; }
    .grade-icon { background-color: #e8f5e9; color: #388e3c; }
    .roster-icon { background-color: #e0f7fa; color: #00acc1; }
    
    .card-content {
        padding: 1.5rem;
        flex-grow: 1;
    }
    
    .card-content h3 {
        margin-top: 0;
        color: #2c3e50;
        font-size: 1.3rem;
    }
    
    .card-content p {
        color: #7f8c8d;
        margin-bottom: 1.5rem;
    }
    
    /* Buttons */
    .btn {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.7rem 1.2rem;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 500;
        transition: all 0.3s ease;
        border: none;
        cursor: pointer;
    }
    
    .btn-primary {
        background-color: #1976d2;
        color: white;
    }
    
    .btn-success {
        background-color: #388e3c;
        color: white;
    }
    
    .btn-info {
        background-color: #00acc1;
        color: white;
    }
    
    .btn:hover {
        opacity: 0.9;
        transform: translateY(-2px);
    }
    
    /* Disabled State */
    .disabled {
        opacity: 0.6;
        pointer-events: none;
        cursor: not-allowed;
    }
    
    /* Icons */
    .icon-welcome::before { content: "👋"; }
    .icon-logout::before { content: "🚪"; }
    .icon-courses::before { content: "📚"; }
    .icon-book::before { content: "📖"; }
    .icon-grade::before { content: "📝"; }
    .icon-roster::before { content: "👥"; }
    .icon-view::before { content: "👀"; }
    .icon-edit::before { content: "✏️"; }
    .icon-list::before { content: "📋"; }
    
    @media (max-width: 768px) {
        .professor-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .header-actions {
            width: 100%;
            justify-content: flex-end;
        }
        
        .dashboard-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>