<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
requireRole('professor');
ensureProfessorContext();

$class_id = $_GET['class_id'] ?? null;
$professor_id = getAssociatedId();

// Validate class access
if (!$class_id) {
    header("Location: courses.php?error=missing_class");
    exit();
}

// Verify professor teaches this class and get class info
$stmt = $pdo->prepare("
    SELECT c.course_name, cl.semester, cl.year 
    FROM classes cl
    JOIN courses c ON cl.course_id = c.course_id
    WHERE cl.class_id = ? AND cl.prof_id = ?
");
$stmt->execute([$class_id, $professor_id]);
$classInfo = $stmt->fetch();

if (!$classInfo) {
    header("Location: courses.php?error=unauthorized");
    exit();
}

// Handle grade submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once __DIR__ . '/process_grades.php'; // Separate processing file
    exit();
}

// Get students with detailed grades
$stmt = $pdo->prepare("
    SELECT 
        s.student_id, 
        s.first_name, 
        s.last_name,
        e.quiz1, e.quiz2, e.quiz3, e.quiz4,
        e.assignment1, e.assignment2, e.assignment3, e.assignment4,
        e.midterm, e.final,
        e.total_mark,
        e.letter_grade
    FROM enrollments e
    JOIN students s ON e.student_id = s.student_id
    WHERE e.class_id = ?
    ORDER BY s.last_name, s.first_name
");
$stmt->execute([$class_id]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Enter Grades - " . htmlspecialchars($classInfo['course_name']);
include __DIR__ . '/../includes/header.php';
?>

<main class="professor-container">
    <div class="professor-header">
        <div>
            <h1><i class="icon-grades"></i> Detailed Grade Management</h1>
            <p class="class-info">
                <?= htmlspecialchars($classInfo['course_name']) ?> • 
                <?= htmlspecialchars($classInfo['semester']) ?> <?= htmlspecialchars($classInfo['year']) ?>
            </p>
        </div>
        <div class="header-actions">
            <a href="roster.php?class_id=<?= $class_id ?>" class="btn-back">
                <i class="icon-back"></i> View Roster
            </a>
        </div>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <i class="icon-success"></i> <?= htmlspecialchars($_SESSION['success']) ?>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <i class="icon-error"></i> <?= htmlspecialchars($_SESSION['error']) ?>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="professor-card">
        <form method="POST" id="gradeForm">
            <input type="hidden" name="class_id" value="<?= $class_id ?>">
            <div class="table-responsive">
                <table class="detailed-grade-table">
                    <thead>
                        <tr>
                            <th rowspan="2">Student</th>
                            <th colspan="4">Quizzes (10 pts each)</th>
                            <th colspan="4">Assignments (10 pts each)</th>
                            <th colspan="2">Exams</th>
                            <th rowspan="2">Total</th>
                            <th rowspan="2">Grade</th>
                        </tr>
                        <tr>
                            <th>Q1</th><th>Q2</th><th>Q3</th><th>Q4</th>
                            <th>A1</th><th>A2</th><th>A3</th><th>A4</th>
                            <th>Midterm (30)</th><th>Final (50)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                        <tr>
                            <td class="student-name">
                                <?= htmlspecialchars($student['last_name'] . ', ' . $student['first_name']) ?>
                                <small>ID: <?= $student['student_id'] ?></small>
                            </td>
                            
                            <!-- Quizzes -->
                            <?php for($i=1; $i<=4; $i++): ?>
                            <td>
                                <input type="number" 
                                    name="grades[<?= $student['student_id'] ?>][quiz<?= $i ?>]"
                                    min="0" max="10" step="0.1" 
                                    value="<?= htmlspecialchars($student['quiz'.$i] ?? 0) ?>"
                                    class="grade-input">
                            </td>
                            <?php endfor; ?>
                            
                            <!-- Assignments -->
                            <?php for($i=1; $i<=4; $i++): ?>
                            <td>
                                <input type="number" 
                                    name="grades[<?= $student['student_id'] ?>][assignment<?= $i ?>]"
                                    min="0" max="10" step="0.1" 
                                    value="<?= htmlspecialchars($student['assignment'.$i] ?? 0) ?>"
                                    class="grade-input">
                            </td>
                            <?php endfor; ?>
                            
                            <!-- Midterm -->
                            <td>
                                <input type="number" 
                                    name="grades[<?= $student['student_id'] ?>][midterm]"
                                    min="0" max="30" step="0.1"
                                    value="<?= htmlspecialchars($student['midterm'] ?? 0) ?>"
                                    class="grade-input">
                            </td>
                            
                            <!-- Final -->
                            <td>
                                <input type="number" 
                                    name="grades[<?= $student['student_id'] ?>][final]"
                                    min="0" max="50" step="0.1"
                                    value="<?= htmlspecialchars($student['final'] ?? 0) ?>"
                                    class="grade-input">
                            </td>
                            
                            <!-- Calculated Values -->
                            <td class="total-mark">
                                <?= number_format($student['total_mark'], 1) ?>
                            </td>
                            <td class="letter-grade grade-<?= strtolower($student['letter_grade']) ?>">
                                <?= $student['letter_grade'] ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="icon-save"></i> Save All Grades
                </button>
                <button type="button" class="btn btn-secondary" onclick="resetForm()">
                    <i class="icon-reset"></i> Reset Changes
                </button>
            </div>
        </form>
    </div>

    <!-- Grading Key -->
    <div class="grading-key">
        <h3>Grading Scale</h3>
        <ul>
            <li><span class="grade-a">A</span> 90-100</li>
            <li><span class="grade-a-">A-</span> 80-89.9</li>
            <li><span class="grade-b">B</span> 70-79.9</li>
            <li><span class="grade-b-">B-</span> 60-69.9</li>
            <li><span class="grade-c">C</span> 50-59.9</li>
            <li><span class="grade-f">F</span> Below 50</li>
        </ul>
    </div>
</main>

<style>
    /* Add to existing styles */
    .detailed-grade-table {
        width: 100%;
        border-collapse: collapse;
        margin: 1rem 0;
    }

    .detailed-grade-table th {
        background-color: #f8f9fa;
        padding: 0.8rem;
        text-align: center;
        vertical-align: middle;
    }

    .detailed-grade-table td {
        padding: 0.6rem;
        border: 1px solid #dee2e6;
        text-align: center;
    }

    .student-name {
        text-align: left;
        min-width: 200px;
    }

    .student-name small {
        display: block;
        color: #6c757d;
        font-size: 0.8em;
    }

    .grade-input {
        width: 60px;
        padding: 0.3rem;
        border: 1px solid #ced4da;
        border-radius: 4px;
        text-align: center;
    }

    .total-mark {
        font-weight: bold;
        background-color: #f8f9fa;
    }

    .letter-grade {
        font-weight: bold;
        text-align: center;
        min-width: 50px;
    }

    .grading-key {
        margin-top: 2rem;
        padding: 1rem;
        background-color: #f8f9fa;
        border-radius: 8px;
    }

    .grading-key ul {
        list-style: none;
        padding: 0;
        display: flex;
        gap: 1.5rem;
        flex-wrap: wrap;
    }

    .grading-key li {
        padding: 0.5rem 1rem;
        border-radius: 4px;
    }

    /* Grade Colors */
    .grade-a { color: #28a745; }
    .grade-a- { color: #218838; }
    .grade-b { color: #ffc107; }
    .grade-b- { color: #fd7e14; }
    .grade-c { color: #17a2b8; }
    .grade-f { color: #dc3545; }
</style>

<script>
    function resetForm() {
        document.querySelectorAll('.grade-input').forEach(input => {
            input.value = input.defaultValue;
        });
    }
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>