<?php
// process_grades.php
require_once __DIR__ . '/../includes/auth.php';
requireRole('professor');
$pdo = getDB();

$class_id = (int)$_POST['class_id'];
$professor_id = getAssociatedId();

// Verify professor access
$verifyStmt = $pdo->prepare("SELECT 1 FROM classes WHERE class_id = ? AND prof_id = ?");
$verifyStmt->execute([$class_id, $professor_id]);

if (!$verifyStmt->fetch()) {
    $_SESSION['error'] = "Unauthorized access to class";
    header("Location: courses.php");
    exit();
}

try {
    $pdo->beginTransaction();
    
    $updateStmt = $pdo->prepare("
        UPDATE enrollments SET
            quiz1 = :quiz1,
            quiz2 = :quiz2,
            quiz3 = :quiz3,
            quiz4 = :quiz4,
            assignment1 = :assignment1,
            assignment2 = :assignment2,
            assignment3 = :assignment3,
            assignment4 = :assignment4,
            midterm = :midterm,
            final = :final
        WHERE student_id = :student_id AND class_id = :class_id
    ");

    foreach ($_POST['grades'] as $student_id => $grades) {
        // Validate input
        $validated = [
            ':student_id' => (int)$student_id,
            ':class_id' => $class_id
        ];
        
        // Validate quizzes
        for ($i = 1; $i <= 4; $i++) {
            $key = "quiz$i";
            $validated[":$key"] = min(max(floatval($grades[$key] ?? 0), 0), 10); // Fixed syntax
        }
        
        // Validate assignments
        for ($i = 1; $i <= 4; $i++) {
            $key = "assignment$i";
            $validated[":$key"] = min(max(floatval($grades[$key] ?? 0), 0), 10); // Fixed syntax
        }
        
        // Validate midterm and final
        $validated[':midterm'] = min(max(floatval($grades['midterm'] ?? 0), 0), 30); // Fixed syntax
        $validated[':final'] = min(max(floatval($grades['final'] ?? 0), 0), 50); // Fixed syntax

        $updateStmt->execute($validated);
        if ($updateStmt->rowCount() === 0) {
            error_log("No rows updated for student ID: $student_id in class: $class_id");
        }
    }
    
    $pdo->commit();
    $_SESSION['success'] = "Grades updated successfully!";
} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = "Error saving grades: " . $e->getMessage();
}

header("Location: grades.php?class_id=$class_id");
exit();
?>