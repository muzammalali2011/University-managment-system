<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
requireRole('professor');
ensureProfessorContext();

// Get professor's courses
$stmt = $pdo->prepare("
    SELECT c.course_id, c.course_name, cl.class_id, cl.semester, cl.year 
    FROM classes cl
    JOIN courses c ON cl.course_id = c.course_id
    WHERE cl.prof_id = ?
    ORDER BY cl.year DESC, cl.semester
");
$stmt->execute([getAssociatedId()]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "My Courses";
include __DIR__ . '/../includes/header.php';
?>

<main class="professor-container">
    <div class="professor-header">
        <h1><i class="icon-courses"></i> My Courses</h1>
        <div class="header-actions">
            <a href="index.php" class="btn-back"><i class="icon-back"></i> Back to Dashboard</a>
        </div>
    </div>

    <?php if (empty($courses)): ?>
        <div class="empty-state">
            <i class="icon-warning"></i>
            <p>No courses assigned to you.</p>
        </div>
    <?php else: ?>
        <div class="professor-card">
            <div class="table-responsive">
                <table class="professor-table">
                    <thead>
                        <tr>
                            <th>Course</th>
                            <th>Semester</th>
                            <th>Year</th>
                            <th class="actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($courses as $course): ?>
                        <tr>
                            <td>
                                <div class="course-title">
                                    <?= htmlspecialchars($course['course_name']) ?>
                                    <small>ID: <?= $course['course_id'] ?></small>
                                </div>
                            </td>
                            <td>
                                <span class="semester-badge semester-<?= strtolower($course['semester']) ?>">
                                    <?= htmlspecialchars($course['semester']) ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($course['year']) ?></td>
                            <td class="actions">
                                <div class="action-buttons">
                                    <a href="roster.php?class_id=<?= $course['class_id'] ?>" 
                                       class="btn btn-primary btn-sm">
                                        <i class="icon-roster"></i> Roster
                                    </a>
                                    <a href="grades.php?class_id=<?= $course['class_id'] ?>" 
                                       class="btn btn-success btn-sm">
                                        <i class="icon-grade"></i> Grades
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</main>

<style>
    /* Reuse professor container styles */
    .professor-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
    }
    
    .professor-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #eee;
    }
    
    .professor-header h1 {
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .btn-back {
        color: #4361ee;
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        transition: all 0.3s ease;
    }
    
    .btn-back:hover {
        background-color: #f0f4ff;
    }
    
    /* Card Styles */
    .professor-card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 15px rgba(0,0,0,0.08);
        padding: 1.5rem;
    }
    
    /* Table Styles */
    .table-responsive {
        overflow-x: auto;
    }
    
    .professor-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .professor-table th {
        background-color: #f8f9fa;
        color: #3a4a6b;
        padding: 0.8rem 1rem;
        text-align: left;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .professor-table td {
        padding: 1rem;
        border-bottom: 1px solid #eee;
        vertical-align: middle;
    }
    
    .professor-table tr:last-child td {
        border-bottom: none;
    }
    
    /* Course Title */
    .course-title small {
        display: block;
        font-size: 0.8rem;
        color: #7f8c8d;
        margin-top: 0.2rem;
    }
    
    /* Semester Badges */
    .semester-badge {
        display: inline-block;
        padding: 0.3rem 0.6rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
    }
    
    .semester-fall {
        background-color: #fff3e0;
        color: #e65100;
    }
    
    .semester-spring {
        background-color: #e8f5e9;
        color: #2e7d32;
    }
    
    .semester-summer {
        background-color: #e3f2fd;
        color: #1565c0;
    }
    
    /* Action Buttons */
    .action-buttons {
        display: flex;
        gap: 0.5rem;
    }
    
    .btn {
        padding: 0.5rem 0.8rem;
        border-radius: 6px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        border: none;
        font-size: 0.85rem;
        text-decoration: none;
    }
    
    .btn-sm {
        padding: 0.4rem 0.7rem;
        font-size: 0.8rem;
    }
    
    .btn-primary {
        background-color: #4361ee;
        color: white;
    }
    
    .btn-success {
        background-color: #4caf50;
        color: white;
    }
    
    .btn:hover {
        opacity: 0.9;
        transform: translateY(-1px);
    }
    
    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 3rem;
        color: #7f8c8d;
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 15px rgba(0,0,0,0.08);
    }
    
    .empty-state i {
        font-size: 2.5rem;
        opacity: 0.5;
        margin-bottom: 1rem;
        display: block;
    }
    
    /* Icons */
    .icon-courses::before { content: "📚"; }
    .icon-back::before { content: "←"; }
    .icon-warning::before { content: "⚠️"; }
    .icon-roster::before { content: "👥"; }
    .icon-grade::before { content: "📝"; }
    
    @media (max-width: 768px) {
        .professor-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .header-actions {
            width: 100%;
            justify-content: flex-end;
        }
        
        .action-buttons {
            flex-direction: column;
        }
    }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>